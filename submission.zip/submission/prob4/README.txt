    - To just run optimizations.c normally, just use "clang optimizations.c && ./a.out" like usual. 
    - To get the time benchmarks for Part 1 of Problem 4, run "./runTimeBenchmark.sh".
      In the code, the rows and columns are both set to 500. You can change the values of these variables in the main function of the program. 
    - To generate the LLVM IR for Part 2 of Problem 4, run "./generateLLVM.sh". 

